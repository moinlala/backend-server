# Architecture Overview

## System Design

```
┌─────────────────────────────────────────────────────────────┐
│                      FastAPI Server                          │
│  (routes/world.py, routes/health.py)                        │
└────────────────────────┬────────────────────────────────────┘
                         │
        ┌────────────────┼────────────────┐
        │                │                │
        ▼                ▼                ▼
┌──────────────┐  ┌────────────────┐  ┌──────────────┐
│   Agents     │  │   Database     │  │   Utils      │
│              │  │                │  │              │
│ • World Gen  │  │ • Models       │  │ • Helpers    │
│ • Validator  │  │ • Service      │  │              │
│ • Events     │  │ • Snapshots    │  │              │
└──────────────┘  └────────────────┘  └──────────────┘
        │                │
        └────────────────┼────────────────┐
                         │                │
        ┌────────────────▼──┐    ┌────────▼─────────┐
        │  Claude API       │    │  SQLite Database │
        │  (Anthropic)      │    │  (world_data.db) │
        └───────────────────┘    └──────────────────┘
```

## Data Flow

### 1. World Generation
```
POST /api/world/generate
    │
    ├─> agents/world_generator.generate_world_data()
    │       │
    │       └─> Claude API (creates JSON structure)
    │
    ├─> database/service.WorldStateService.update()
    │       │
    │       └─> SQLite: INSERT/UPDATE world_state
    │
    └─> database/service.WorldStateService.create_snapshot()
            │
            └─> SQLite: INSERT snapshots (initial backup)
```

### 2. Update Validation & Application
```
POST /api/world/update
    │
    ├─> agents/validator.validate_update()
    │       │
    │       └─> Claude API (logical consistency check)
    │
    ├─> [if valid]
    │   ├─> agents/validator.apply_update()
    │   │
    │   ├─> database/service.WorldStateService.update()
    │   │   └─> SQLite: UPDATE world_state
    │   │
    │   └─> database/service.WorldStateService.create_snapshot()
    │       └─> SQLite: INSERT snapshots (change record)
    │
    └─> [if invalid] Return errors & recommendations
```

### 3. Event Suggestion
```
POST /api/world/events/suggest
    │
    ├─> agents/world_generator.suggest_event()
    │       │
    │       └─> Claude API (creates event based on world state)
    │
    └─> database/service.EventService.add_event()
            │
            └─> SQLite: INSERT events (status: "suggested")
```

### 4. Rollback
```
POST /api/world/rollback
    │
    ├─> database/service.WorldStateService.rollback_to_snapshot()
    │       │
    │       ├─> SQLite: CREATE backup snapshot
    │       │   (current state before restore)
    │       │
    │       ├─> SQLite: SELECT snapshot data
    │       │
    │       └─> SQLite: UPDATE world_state (restore)
    │
    └─> Return success & timestamp
```

## Component Details

### Agents (AI Logic)

**world_generator.py**
- `generate_world_data()`: Uses Claude to create coherent world structures
- `suggest_event()`: Analyzes current world state and suggests logical events
- Handles Claude API communication and response parsing

**validator.py**
- `validate_update()`: AI-powered validation of proposed changes
- `apply_update()`: Applies validated changes to world state
- Checks for logical consistency, balance, dependencies, and realism

### Database (Persistence)

**models.py**
- `WorldState`: Current world data (JSON)
- `Snapshot`: Point-in-time backup for rollback
- `Event`: Audit trail of all events
- `init_db()`: Create tables
- `get_db()`: FastAPI dependency injection

**service.py**
- `WorldStateService`: CRUD for world state, snapshot management
- `EventService`: Event management and status tracking
- All operations transaction-safe

### API Routes

**routes/world.py**
- `POST /api/world/generate`: Create new world
- `GET /api/world/current`: Retrieve current state
- `POST /api/world/validate`: Validate update
- `POST /api/world/update`: Apply validated update
- `POST /api/world/events/suggest`: Get AI suggestion
- `POST /api/world/snapshots`: Create manual snapshot
- `GET /api/world/snapshots`: List available snapshots
- `POST /api/world/rollback`: Restore from snapshot

**routes/health.py**
- `GET /health`: Health check
- `GET /`: Root with endpoint info

### Data Models (Schemas)

**schemas.py** defines all request/response models:
- `WorldData`: Complete world structure
- `RegionData`, `CityData`, `ResourceData`: World components
- `UpdateRequest`: Update specification
- `ValidationResult`: Validation output
- `EventSuggestion`: Suggested event
- And more...

## Key Design Decisions

### 1. AI Integration
- **Why Claude**: Excellent at generating coherent structures and validating logical consistency
- **Synchronous calls**: Keeps implementation simple; async can be added later
- **JSON parsing**: Claude instructed to return pure JSON for reliable parsing

### 2. Database
- **SQLite**: Perfect for prototype/small deployments; easy migration to PostgreSQL
- **JSON columns**: Flexible schema, stores complex nested structures
- **Service layer**: Abstraction between API and database for testability

### 3. Snapshots
- **Automatic on changes**: Every update creates a snapshot automatically
- **Manual snapshots**: Users can create named checkpoints
- **Backup on rollback**: Current state saved before restore

### 4. Validation
- **Pre-application**: Catches issues before database changes
- **AI-powered**: Semantic validation beyond schema checks
- **Reversible**: Snapshots allow undoing bad updates

### 5. Event System
- **Suggested first**: Events start as "suggested" for review
- **Status tracking**: Full audit trail (suggested → applied or rejected)
- **World-aware**: Events generated based on actual world state

## Scalability Considerations

### Current (Single-Machine)
- SQLite file-based (localhost only)
- Synchronous requests to Claude API
- Good for prototyping and development

### For Production
1. **Database**: Switch to PostgreSQL (change `DATABASE_URL`)
2. **Caching**: Add Redis for frequent queries
3. **Async**: Use `async`/`await` for concurrent Claude calls
4. **Rate limiting**: Implement quota for Claude API costs
5. **Queue**: Use Celery/RabbitMQ for heavy operations
6. **Logging**: Structured logging for debugging
7. **Monitoring**: Add metrics/APM

## Security Notes

### Current Implementation
- ⚠️ No authentication (assumes trusted environment)
- ⚠️ CORS allows all origins (development only)
- ✅ SQL injection safe (SQLAlchemy ORM)
- ✅ Input validation (Pydantic schemas)

### For Production
- Add JWT authentication
- Restrict CORS to specific origins
- Implement role-based access control
- Add request signing and validation
- Secure API key management

## Performance Profile

| Operation | Time | Bottleneck |
|-----------|------|-----------|
| Generate world | 5-10s | Claude API |
| Validate update | 3-5s | Claude API |
| Suggest event | 5-8s | Claude API |
| Apply update | <100ms | SQLite |
| Create snapshot | <50ms | SQLite |
| List snapshots | <10ms | SQLite |
| Rollback | <100ms | SQLite |

All Claude operations are network-bound. Parallelizing requests would significantly improve throughput.

## Testing Strategy

### Unit Tests
- Database service layer
- Schema validation
- Helper functions

### Integration Tests
- Full update workflow
- Snapshot creation and rollback
- Event suggestion and application

### E2E Tests
- Complete user workflows
- API endpoint behavior
- Error handling

See `tests/` directory for implementation.
