#!/bin/bash
# Quick start script for macOS/Linux

echo "========================================"
echo "   World AI Backend - Quick Start"
echo "========================================"

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Error: Python 3 is not installed"
    exit 1
fi

echo ""
echo "Creating virtual environment..."
python3 -m venv venv

echo ""
echo "Activating virtual environment..."
source venv/bin/activate

echo ""
echo "Installing dependencies..."
pip install -r requirements.txt

echo ""
echo ""
echo "========================================"
echo "   Setup Complete!"
echo "========================================"
echo ""
echo "Next steps:"
echo "   1. Edit .env and add your ANTHROPIC_API_KEY"
echo "   2. Run the server: python app/main.py"
echo "   3. Visit http://localhost:8000/docs"
echo ""
echo "To activate venv in the future:"
echo "   source venv/bin/activate"
echo ""
