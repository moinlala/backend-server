# Getting Started - Quick Start & Detailed Guide

## ⚡ Quick Start (60 seconds)

```powershell
# 1. Set API key
$env:ANTHROPIC_API_KEY = 'your-api-key-here'

# 2. Run everything
python run.py
```

That's it! The system will:
- Start the FastAPI server
- Generate a sample world
- Run example API calls
- Save snapshots to `storage/snapshots/`

## Prerequisites

- **Python 3.9+** - Download from [python.org](https://www.python.org/downloads/)
- **Anthropic API Key** - Get from [console.anthropic.com](https://console.anthropic.com)
  - Free trial includes $5 credits for Claude API

## Step-by-Step Installation & Setup

### Step 1: Set Up the Project

**Windows (PowerShell):**
```powershell
cd "d:\mvp client\world-ai-backend"
```

**macOS/Linux:**
```bash
cd "d:\mvp client\world-ai-backend"
```

### Step 2: Create Virtual Environment

**Windows:**
```powershell
python -m venv venv
venv\Scripts\Activate.ps1
```

**macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

### Step 4: Configure API Key

**Option A: Set as environment variable**

Windows (PowerShell):
```powershell
$env:ANTHROPIC_API_KEY = 'sk-ant-xxxxxxxxxxxxx'
```

macOS/Linux (Bash):
```bash
export ANTHROPIC_API_KEY='sk-ant-xxxxxxxxxxxxx'
```

**Option B: Create .env file**

```powershell
Copy-Item .env.example .env
# Edit .env in your editor
notepad .env
```

Contents:
```env
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx
DATABASE_URL=sqlite:///./world_data.db
DEBUG=False
```

### Step 5: Run the System

**Quick Start (automatic demo):**
```powershell
python run.py
```

**Manual Mode (if you prefer):**
```powershell
python -m uvicorn app.main:app --reload
```

Then in another terminal:
```powershell
python example_usage.py
```

## ✅ Verification - Is It Working?

1. **Server started?**
   ```powershell
   curl http://localhost:8000/health
   ```
   Should return: `{"status":"ok"}`

2. **Database created?**
   ```powershell
   # Check for world_data.db
   ls world_data.db
   ```

3. **Snapshots saved?**
   ```powershell
   # Check for snapshot files
   ls storage/snapshots/
   ```

## 🌐 Accessing the API

### Interactive Swagger UI (Best for Testing)
```
http://localhost:8000/docs
```

Click any endpoint to test it directly in your browser!

### API Endpoints

| Endpoint | Method | What It Does |
|----------|--------|-------------|
| `/health` | GET | Server status |
| `/api/world/generate` | POST | Create new world (3-10 regions) |
| `/api/world/current` | GET | View current world |
| `/api/world/summary` | GET | Quick stats |
| `/api/world/validate` | POST | Check if update is valid |
| `/api/world/update` | POST | Apply update & save snapshot |
| `/api/world/events/suggest` | POST | Get AI-suggested event |
| `/api/world/events` | GET | View all events |
| `/api/world/snapshots` | GET | View all saved snapshots |
| `/api/world/rollback` | POST | Restore to previous snapshot |

## 📁 Project Structure

```
world-ai-backend/
├── app/                    # Main application
│   ├── agents/            # AI agents
│   │   ├── world_generator.py
│   │   └── validator.py
│   ├── database/          # Data layer
│   │   ├── models.py
│   │   └── service.py
│   ├── routes/            # API endpoints
│   │   ├── health.py
│   │   └── world.py
│   ├── utils/             # Helpers
│   │   └── helpers.py
│   ├── config.py
│   └── main.py
├── storage/
│   └── snapshots/         # Saved world snapshots (JSON)
├── requirements.txt
├── .env.example
├── example_usage.py       # Example API calls
├── run.py                 # Quick start script
├── README.md              # Full documentation
└── GETTING_STARTED.md     # This file
```

## 🛠️ Configuration Options

Edit `.env` to customize:

```env
# Required
ANTHROPIC_API_KEY=sk-ant-your-key

# Optional - which Claude model to use
ANTHROPIC_MODEL=claude-3-5-sonnet-20241022

# Optional - database location
DATABASE_URL=sqlite:///./world_data.db

# Optional - show detailed logs
DEBUG=True
```

## 📊 Understanding Snapshots

Every world modification creates an automatic snapshot for rollback.

**Snapshots are stored as clean JSON in:**
```
storage/snapshots/
```

**Example snapshot structure:**
```json
{
  "metadata": {
    "name": "sample_world",
    "created_at": "2025-01-15T10:30:00",
    "version": "1.0.0"
  },
  "world": {
    "regions": [...],
    "metadata": {...}
  }
}
```

You can manually load these into the world state if needed.

## 🔧 Troubleshooting

### "ANTHROPIC_API_KEY not found"
```powershell
# Make sure key is set
echo $env:ANTHROPIC_API_KEY

# If empty, set it
$env:ANTHROPIC_API_KEY = 'your-key-here'

# Or use .env file instead
```

### "Connection refused" when running examples
1. Make sure server is running in another terminal
2. Check that port 8000 is available: `netstat -ano | findstr 8000`
3. Try a different port: `python -m uvicorn app.main:app --port 8001`

### "Address already in use"
```powershell
# Find what's using port 8000
netstat -ano | findstr :8000

# Kill the process (replace PID)
taskkill /PID 12345 /F

# Or use different port
python -m uvicorn app.main:app --port 8001
```

### "ModuleNotFoundError"
```powershell
# Make sure virtual environment is activated
venv\Scripts\Activate.ps1

# Reinstall dependencies
pip install -r requirements.txt
```

## 🚀 Next Steps

1. ✅ Run `python run.py`
2. ✅ Open http://localhost:8000/docs
3. ✅ Try the example endpoints
4. ✅ Check `storage/snapshots/` for output
5. ✅ Read [README.md](README.md) for detailed API docs

## 📚 Documentation

- **Full API Reference**: [README.md](README.md)
- **FastAPI Docs**: https://fastapi.tiangolo.com
- **Anthropic Docs**: https://docs.anthropic.com
- **SQLAlchemy Docs**: https://docs.sqlalchemy.org
source venv/bin/activate    # macOS/Linux
```

Start the server:
```powershell
python app/main.py
```

Or with auto-reload (for development):
```powershell
python -m uvicorn app.main:app --reload
```

Expected output:
```
INFO:     Uvicorn running on http://127.0.0.1:8000
INFO:     Application startup complete
```

### Step 4: Access the API

Open your browser or use curl:

- **Interactive Docs:** `http://localhost:8000/docs`
- **ReDoc:** `http://localhost:8000/redoc`
- **API Root:** `http://localhost:8000`

## Quick Test

### Using the Example Script

```powershell
# Make sure server is running in another terminal/window
python example_usage.py
```

This will:
1. Check server health
2. Generate a new world
3. Show world summary
4. Validate an update
5. Apply the update
6. Suggest an event
7. List events
8. Show snapshots

### Using curl

```powershell
# Generate a world
curl -X POST http://localhost:8000/api/world/generate?num_regions=3

# Get current world
curl http://localhost:8000/api/world/current

# Get summary
curl http://localhost:8000/api/world/summary

# Suggest an event
curl -X POST http://localhost:8000/api/world/events/suggest
```

### Using the Interactive API Docs

1. Visit `http://localhost:8000/docs`
2. Click on any endpoint
3. Click "Try it out"
4. Fill in parameters and click "Execute"

## Project Structure

```
world-ai-backend/
├── app/                    # Main application
│   ├── agents/            # AI logic
│   ├── database/          # Database layer
│   ├── models/            # Schemas
│   ├── routes/            # API endpoints
│   ├── utils/             # Helpers
│   ├── config.py          # Configuration
│   └── main.py            # FastAPI app
├── tests/                 # Unit tests
├── example_usage.py       # Example script
├── requirements.txt       # Python dependencies
├── .env.example          # Environment template
├── setup.bat/setup.sh    # Setup scripts
├── README.md             # Full documentation
└── ARCHITECTURE.md       # Architecture details
```

## Common Commands

```powershell
# Activate virtual environment
venv\Scripts\activate.bat

# Deactivate virtual environment
deactivate

# Install a new package
pip install package_name

# Run tests
pytest tests/ -v

# Run tests with coverage
pytest tests/ --cov=app

# Generate requirements.txt
pip freeze > requirements.txt
```

## Troubleshooting

### "Python is not installed"
- Download Python from [python.org](https://www.python.org/downloads/)
- Make sure to check "Add Python to PATH" during installation
- Restart your terminal after installation

### "ModuleNotFoundError"
- Make sure virtual environment is activated
- Run `pip install -r requirements.txt`

### "API key not found"
- Check that `.env` file exists and is in the project root
- Verify `ANTHROPIC_API_KEY` is set correctly
- Make sure there are no typos

### "Connection refused" when accessing API
- Make sure server is running: `python app/main.py`
- Check that port 8000 is not in use
- Try a different port: `python -m uvicorn app.main:app --port 8001`

### Claude API rate limit errors
- Wait a few minutes between requests
- Check your Anthropic API quota
- Consider implementing request queuing (see ARCHITECTURE.md)

## Next Steps

1. **Read the Documentation**
   - `README.md`: Full feature overview and API reference
   - `ARCHITECTURE.md`: System design and components

2. **Explore the API**
   - Start with `/api/world/generate` to create a world
   - Then try `/api/world/current` to view it
   - Use `/api/world/validate` before applying updates

3. **Run Tests**
   ```powershell
   pytest tests/ -v
   ```

4. **Customize**
   - Modify agent prompts in `app/agents/`
   - Adjust database schema in `app/database/models.py`
   - Add new endpoints in `app/routes/`

5. **Deploy** (see README.md for production considerations)

## Support

- **FastAPI Docs:** https://fastapi.tiangolo.com
- **Anthropic API Docs:** https://docs.anthropic.com
- **Python Virtual Environments:** https://docs.python.org/3/tutorial/venv.html

## Success Checklist

- [ ] Python 3.9+ installed
- [ ] Anthropic API key obtained
- [ ] Project cloned/downloaded
- [ ] Virtual environment created and activated
- [ ] Dependencies installed (`pip install -r requirements.txt`)
- [ ] `.env` file configured with API key
- [ ] Server running (`python app/main.py`)
- [ ] Can access `http://localhost:8000/docs`
- [ ] Example script runs successfully
- [ ] Generated a world and viewed it

If all items are checked, you're ready to develop and extend the system!
