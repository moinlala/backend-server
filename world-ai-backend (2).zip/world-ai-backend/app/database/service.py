import sys
import os
print(f"DEBUG: Current working directory: {os.getcwd()}")
print(f"DEBUG: Python path: {sys.path[:3]}...")  # Show first 3 paths
try:
    from app.database.models import WorldState, Snapshot, Event, init_db
    print("DEBUG: Successfully imported from app.database.models")
except ImportError as e:
    print(f"DEBUG: Failed to import from app.database.models: {e}")
    print(f"DEBUG: Checking if app directory exists: {os.path.exists('app')}")
    print(f"DEBUG: Checking if app/database exists: {os.path.exists('app/database')}")
    raise

from sqlalchemy.orm import Session
from app.models.schemas import WorldData, EventSuggestion
import json
from datetime import datetime
from typing import Optional, List


class WorldStateService:
    """Service for managing world state."""
    
    @staticmethod
    def init():
        """Initialize the database."""
        init_db()
    
    @staticmethod
    def get_or_create(db: Session) -> WorldState:
        """Get current world state or create empty one."""
        world = db.query(WorldState).first()
        if not world:
            world = WorldState(data={
                "regions": [],
                "metadata": {}
            })
            db.add(world)
            db.commit()
            db.refresh(world)
        return world
    
    @staticmethod
    def update(db: Session, world_data: WorldData) -> WorldState:
        """Update world state and create snapshot."""
        world = db.query(WorldState).first()
        if not world:
            world = WorldState(data=world_data.dict())
        else:
            world.data = world_data.dict()
            world.updated_at = datetime.utcnow()
        
        db.add(world)
        db.commit()
        db.refresh(world)
        return world
    
    @staticmethod
    def get_data(db: Session) -> WorldData:
        """Get current world data as schema object."""
        world = WorldStateService.get_or_create(db)
        return WorldData(**world.data)
    
    @staticmethod
    def create_snapshot(
        db: Session,
        description: str = "Manual snapshot"
    ) -> Snapshot:
        """Create a snapshot of current world state."""
        world = WorldStateService.get_or_create(db)
        
        snapshot = Snapshot(
            world_state_id=world.id,
            data=world.data,
            description=description
        )
        db.add(snapshot)
        db.commit()
        db.refresh(snapshot)
        return snapshot
    
    @staticmethod
    def list_snapshots(db: Session, limit: int = 10) -> List[Snapshot]:
        """List recent snapshots."""
        return db.query(Snapshot).order_by(Snapshot.created_at.desc()).limit(limit).all()
    
    @staticmethod
    def rollback_to_snapshot(db: Session, snapshot_id: int) -> WorldState:
        """Rollback world state to a specific snapshot."""
        snapshot = db.query(Snapshot).filter(Snapshot.id == snapshot_id).first()
        if not snapshot:
            raise ValueError(f"Snapshot {snapshot_id} not found")
        
        world = db.query(WorldState).filter(WorldState.id == snapshot.world_state_id).first()
        if not world:
            raise ValueError("World state not found")
        
        # Create backup snapshot before rolling back
        backup = Snapshot(
            world_state_id=world.id,
            data=world.data,
            description=f"Backup before rollback to snapshot {snapshot_id}"
        )
        db.add(backup)
        
        # Restore state
        world.data = snapshot.data
        world.updated_at = datetime.utcnow()
        db.add(world)
        db.commit()
        db.refresh(world)
        return world


class EventService:
    """Service for managing events."""
    
    @staticmethod
    def add_event(
        db: Session,
        event_data: dict,
        status: str = "suggested"
    ) -> Event:
        """Add an event to the world."""
        world = WorldStateService.get_or_create(db)
        
        event = Event(
            world_state_id=world.id,
            event_data=event_data,
            status=status
        )
        db.add(event)
        db.commit()
        db.refresh(event)
        return event
    
    @staticmethod
    def get_events(
        db: Session,
        status: Optional[str] = None,
        limit: int = 20
    ) -> List[Event]:
        """Get events, optionally filtered by status."""
        query = db.query(Event).order_by(Event.created_at.desc())
        if status:
            query = query.filter(Event.status == status)
        return query.limit(limit).all()
    
    @staticmethod
    def update_event_status(
        db: Session,
        event_id: int,
        status: str
    ) -> Event:
        """Update event status."""
        event = db.query(Event).filter(Event.id == event_id).first()
        if not event:
            raise ValueError(f"Event {event_id} not found")
        
        event.status = status
        db.add(event)
        db.commit()
        db.refresh(event)
        return event
