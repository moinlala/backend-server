from sqlalchemy import Column, Integer, String, DateTime, JSON, Text, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime
from app.config import config

Base = declarative_base()

class WorldState(Base):
    """Represents the current state of the world."""
    __tablename__ = "world_state"

    id = Column(Integer, primary_key=True, index=True)
    data = Column(JSON, nullable=False)  # {regions: [], cities: [], resources: []}
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Snapshot(Base):
    """Snapshot of world state for rollback capability."""
    __tablename__ = "snapshots"

    id = Column(Integer, primary_key=True, index=True)
    world_state_id = Column(Integer, index=True)
    data = Column(JSON, nullable=False)
    description = Column(String(255))
    created_at = Column(DateTime, default=datetime.utcnow)


class Event(Base):
    """Suggested or applied events in the world."""
    __tablename__ = "events"

    id = Column(Integer, primary_key=True, index=True)
    world_state_id = Column(Integer, index=True)
    event_data = Column(JSON, nullable=False)  # {type, description, affected_regions, etc}
    status = Column(String(50), default="suggested")  # suggested, applied, rejected
    created_at = Column(DateTime, default=datetime.utcnow)


# Database setup
engine = create_engine(
    config.DATABASE_URL,
    connect_args={"check_same_thread": False} if "sqlite" in config.DATABASE_URL else {}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """Initialize database tables."""
    Base.metadata.create_all(bind=engine)


def get_db():
    """Dependency for FastAPI to get database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
