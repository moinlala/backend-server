from app.models.schemas import WorldData, UpdateRequest, ValidationResult
from typing import Tuple

def validate_update(
    update_request: UpdateRequest,
    current_world: WorldData
) -> ValidationResult:
    """
    Validates an update request with deterministic, rule-based logic.
    """
    errors = []
    
    # Find the target city
    target_city = next(
        (
            city
            for region in current_world.regions
            for city in region.cities
            if city.id == update_request.target
        ),
        None,
    )
    
    if not target_city:
        errors.append(f"City '{update_request.target}' not found.")
        return ValidationResult(is_valid=False, errors=errors, warnings=[], recommendations=[])

    if update_request.action == "update_resource":
        resource_name = update_request.changes.get("name")
        new_quantity = update_request.changes.get("quantity")

        # Find the resource to update
        target_resource = next(
            (r for r in target_city.resources if r.name == resource_name), None
        )
        
        if not target_resource:
            errors.append(f"Resource '{resource_name}' not found in city '{target_city.name}'.")
        
        if not isinstance(new_quantity, int) or new_quantity < 0:
            errors.append("Resource quantity must be a non-negative integer.")

    elif update_request.action == "update_population":
        new_population = update_request.changes.get("population")
        if not isinstance(new_population, int) or new_population < 0:
            errors.append("Population must be a non-negative integer.")
            
    else:
        errors.append(f"Unsupported action: '{update_request.action}'.")

    return ValidationResult(is_valid=not errors, errors=errors, warnings=[], recommendations=[])

def apply_update(
    update_request: UpdateRequest,
    current_world: WorldData
) -> Tuple[WorldData, str]:
    """
    Applies a validated update to the world state.
    """
    world_dict = current_world.dict()

    for region in world_dict["regions"]:
        for city in region["cities"]:
            if city["id"] == update_request.target:
                if update_request.action == "update_resource":
                    resource_name = update_request.changes.get("name")
                    for r in city["resources"]:
                        if r["name"] == resource_name:
                            r.update(update_request.changes)
                            break
                elif update_request.action == "update_population":
                    city["population"] = update_request.changes.get("population")
                
                summary = f"Updated {update_request.action} for city {update_request.target}"
                return WorldData(**world_dict), summary
    
    raise ValueError(f"Target city '{update_request.target}' not found.")
