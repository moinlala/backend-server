import random
from app.models.schemas import RegionData, CityData, ResourceData, WorldData

def _generate_resource(name: str, resource_type: str, rarity: str) -> ResourceData:
    """Generates a resource with a quantity based on rarity."""
    quantity = 1000 if rarity == "common" else 200
    return ResourceData(name=name, type=resource_type, quantity=quantity, rarity=rarity)

def _generate_city(city_id: int, region_id: int, climate: str, terrain: str) -> CityData:
    """Generates a city with resources based on climate and terrain."""
    resources = {
        "temperate_plains": [_generate_resource("Wheat", "agricultural", "common")],
        "cold_mountains": [_generate_resource("Iron", "mineral", "common")],
        "arid_desert": [_generate_resource("Sand", "mineral", "common")],
    }
    key = f"{climate}_{terrain}"
    city_resources = resources.get(key, [])
    
    return CityData(
        id=f"city_{city_id}",
        name=f"City {city_id}",
        region_id=f"region_{region_id}",
        population=50000,
        resources=city_resources,
        description=f"A city in a {climate} {terrain}.",
    )

def _generate_region(region_id: int, climate: str, terrain: str) -> RegionData:
    """Generates a region with a set of cities."""
    cities = [
        _generate_city(i, region_id, climate, terrain)
        for i in range((region_id - 1) * 2 + 1, region_id * 2 + 1)
    ]
    return RegionData(
        id=f"region_{region_id}",
        name=f"Region {region_id}",
        climate=climate,
        terrain=terrain,
        cities=cities,
        description=f"A {climate} region with {terrain}.",
    )

def generate_world_data(num_regions: int = 3) -> WorldData:
    """
    Generates a complete world with regions, cities, and resources using deterministic logic.
    """
    regions = [
        _generate_region(1, "temperate", "plains"),
        _generate_region(2, "cold", "mountains"),
        _generate_region(3, "arid", "desert"),
    ]
    
    return WorldData(
        regions=regions[:num_regions],
        metadata={"world_age": "New", "technology_level": "Basic"},
    )

def suggest_event(world_data: WorldData) -> dict:
    """
    Suggests a basic logical event based on the current world state.
    """
    city = random.choice([c for r in world_data.regions for c in r.cities])
    
    if random.choice([True, False]):
        return {
            "type": "population_increase",
            "description": f"City {city.name} population increased by 5%",
            "target_city": city.id,
        }
    
    resource = random.choice(city.resources)
    return {
        "type": "resource_decrease",
        "description": f"Resource {resource.name} in {city.name} decreased by 10%",
        "target_city": city.id,
        "target_resource": resource.name,
    }
