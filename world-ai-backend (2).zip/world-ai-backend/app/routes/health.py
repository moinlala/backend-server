from fastapi import APIRouter

router = APIRouter(tags=["health"])


@router.get("/health")
def health_check():
    """Health check endpoint."""
    return {"status": "ok"}


@router.get("/")
def root():
    """Root endpoint."""
    return {
        "name": "World AI Backend",
        "version": "1.0.0",
        "description": "AI-powered world generation and management system",
        "endpoints": {
            "health": "/health",
            "docs": "/docs",
            "world": "/api/world/*"
        }
    }
