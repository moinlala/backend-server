from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database.models import get_db
from app.database.service import WorldStateService, EventService
from app.models.schemas import (
    WorldData, UpdateRequest, ValidationResult, 
    SnapshotResponse, RollbackRequest
)
from app.agents.world_generator import generate_world_data, suggest_event
from app.agents.validator import validate_update, apply_update
from app.utils.helpers import get_world_summary
from datetime import datetime
from typing import List, Optional

router = APIRouter(prefix="/api/world", tags=["world"])

@router.post("/generate", response_model=WorldData)
def generate_world(num_regions: int = 3, db: Session = Depends(get_db)):
    """
    Generate a new world with a predictable structure.
    """
    try:
        world_data = generate_world_data(num_regions=num_regions)
        WorldStateService.update(db, world_data)
        
        WorldStateService.create_snapshot(
            db, 
            description="Initial world generation"
        )
        
        return world_data
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Generation failed: {str(e)}")

@router.get("/current", response_model=WorldData)
def get_current_world(db: Session = Depends(get_db)):
    """
    Get the current world state.
    """
    return WorldStateService.get_data(db)

@router.get("/summary")
def get_summary(db: Session = Depends(get_db)):
    """
    Get a summary of the current world (counts, names, structure).
    """
    world = WorldStateService.get_data(db)
    return get_world_summary(world)

@router.post("/validate", response_model=ValidationResult)
def validate_world_update(
    update_request: UpdateRequest,
    db: Session = Depends(get_db)
):
    """
    Validate an update request before applying it.
    """
    try:
        world = WorldStateService.get_data(db)
        result = validate_update(update_request, world)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Validation failed: {str(e)}")

@router.post("/update", response_model=dict)
def apply_world_update(
    update_request: UpdateRequest,
    db: Session = Depends(get_db)
):
    """
    Validate and apply an update to the world.
    """
    try:
        world = WorldStateService.get_data(db)
        
        validation = validate_update(update_request, world)
        if not validation.is_valid:
            raise HTTPException(
                status_code=400,
                detail={
                    "message": "Update validation failed",
                    "errors": validation.errors,
                }
            )
        
        updated_world, summary = apply_update(update_request, world)
        WorldStateService.update(db, updated_world)
        
        snapshot = WorldStateService.create_snapshot(
            db,
            description=summary
        )
        
        return {
            "success": True,
            "message": summary,
            "snapshot_id": snapshot.id,
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Update failed: {str(e)}")

@router.post("/events/suggest")
def suggest_world_event(db: Session = Depends(get_db)):
    """
    Suggest a new logical event based on the current world state.
    """
    try:
        world = WorldStateService.get_data(db)
        event_data = suggest_event(world)
        
        event = EventService.add_event(db, event_data, status="suggested")
        
        return {
            "event_id": event.id,
            "event": event_data
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Event suggestion failed: {str(e)}")

@router.get("/events", response_model=List[dict])
def list_events(status: Optional[str] = None, db: Session = Depends(get_db)):
    """
    List events, optionally filtered by status (suggested, applied, rejected).
    """
    events = EventService.get_events(db, status=status)
    return [
        {
            "id": e.id,
            "status": e.status,
            "data": e.event_data,
            "created_at": e.created_at
        }
        for e in events
    ]

@router.post("/events/{event_id}/apply")
def apply_event(event_id: int, db: Session = Depends(get_db)):
    """
    Apply a suggested event by marking it as applied.
    """
    try:
        event = EventService.update_event_status(db, event_id, "applied")
        
        WorldStateService.create_snapshot(
            db,
            description=f"Event applied: {event.event_data.get('type', 'unknown')}"
        )
        
        return {
            "success": True,
            "message": f"Event {event_id} applied",
            "event": event.event_data
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/snapshots")
def create_snapshot(description: str = "Manual snapshot", db: Session = Depends(get_db)):
    """
    Create a snapshot of the current world state.
    """
    try:
        snapshot = WorldStateService.create_snapshot(db, description)
        return {
            "id": snapshot.id,
            "description": snapshot.description,
            "created_at": snapshot.created_at
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/snapshots", response_model=List[SnapshotResponse])
def list_snapshots(limit: int = 10, db: Session = Depends(get_db)):
    """
    List available snapshots for rollback.
    """
    snapshots = WorldStateService.list_snapshots(db, limit=limit)
    return [SnapshotResponse.from_orm(s) for s in snapshots]

@router.post("/rollback")
def rollback_world(request: RollbackRequest, db: Session = Depends(get_db)):
    """
    Rollback world state to a previous snapshot.
    """
    try:
        WorldStateService.rollback_to_snapshot(db, request.snapshot_id)
        return {
            "success": True,
            "message": f"Rolled back to snapshot {request.snapshot_id}",
            "timestamp": datetime.utcnow()
        }
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
