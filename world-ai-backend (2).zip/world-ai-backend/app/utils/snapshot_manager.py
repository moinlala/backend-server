"""
Snapshot file manager - saves and loads snapshots to/from the filesystem.
Provides deterministic, clean JSON output for testing and documentation.
"""

import json
import os
from pathlib import Path
from datetime import datetime
from typing import Dict, Any, Optional, List
from app.models.schemas import WorldData


# Storage directory for snapshots
SNAPSHOTS_DIR = Path(__file__).parent.parent.parent / "storage" / "snapshots"


def ensure_snapshots_dir():
    """Ensure snapshots directory exists."""
    SNAPSHOTS_DIR.mkdir(parents=True, exist_ok=True)


def save_snapshot(world_data: WorldData, name: str) -> str:
    """
    Save a world snapshot to JSON file with deterministic formatting.
    
    Args:
        world_data: World data to save
        name: Base name for the snapshot (without extension)
        
    Returns:
        str: Path to saved file
    """
    ensure_snapshots_dir()
    
    # Create deterministic filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{name}_{timestamp}.json"
    filepath = SNAPSHOTS_DIR / filename
    
    # Convert to dict and ensure clean JSON structure
    data = {
        "metadata": {
            "name": name,
            "created_at": datetime.now().isoformat(),
            "version": "1.0.0"
        },
        "world": world_data.dict()
    }
    
    # Write with clean formatting
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=False)
    
    return str(filepath)


def save_event(event_data: Dict[str, Any], event_type: str) -> str:
    """
    Save an event suggestion to JSON file.
    
    Args:
        event_data: Event data
        event_type: Type of event for naming
        
    Returns:
        str: Path to saved file
    """
    ensure_snapshots_dir()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"event_{event_type}_{timestamp}.json"
    filepath = SNAPSHOTS_DIR / filename
    
    data = {
        "metadata": {
            "type": event_type,
            "created_at": datetime.now().isoformat(),
            "version": "1.0.0"
        },
        "event": event_data
    }
    
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=False)
    
    return str(filepath)


def save_validation_result(
    validation_data: Dict[str, Any],
    request_id: str
) -> str:
    """
    Save a validation result to JSON file.
    
    Args:
        validation_data: Validation result
        request_id: ID of the request being validated
        
    Returns:
        str: Path to saved file
    """
    ensure_snapshots_dir()
    
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"validation_{request_id}_{timestamp}.json"
    filepath = SNAPSHOTS_DIR / filename
    
    data = {
        "metadata": {
            "request_id": request_id,
            "created_at": datetime.now().isoformat(),
            "version": "1.0.0"
        },
        "validation": validation_data
    }
    
    with open(filepath, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False, sort_keys=False)
    
    return str(filepath)


def list_snapshots() -> List[Dict[str, str]]:
    """
    List all saved snapshots.
    
    Returns:
        List of snapshot info (name, path, created_at)
    """
    ensure_snapshots_dir()
    
    snapshots = []
    for filepath in sorted(SNAPSHOTS_DIR.glob("*.json")):
        try:
            with open(filepath, "r", encoding="utf-8") as f:
                data = json.load(f)
                snapshots.append({
                    "name": data.get("metadata", {}).get("name", filepath.stem),
                    "path": str(filepath),
                    "created_at": data.get("metadata", {}).get("created_at", "")
                })
        except Exception:
            pass
    
    return snapshots


def load_snapshot(filepath: str) -> Optional[WorldData]:
    """
    Load a snapshot from JSON file.
    
    Args:
        filepath: Path to snapshot file
        
    Returns:
        WorldData if successful, None otherwise
    """
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            data = json.load(f)
            return WorldData(**data.get("world", {}))
    except Exception as e:
        print(f"Error loading snapshot: {e}")
        return None


def get_snapshots_dir() -> Path:
    """Get the snapshots directory path."""
    return SNAPSHOTS_DIR
