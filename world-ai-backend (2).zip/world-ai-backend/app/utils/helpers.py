# Utility functions for common operations
from typing import Dict, Any, Optional
from app.models.schemas import WorldData


def find_region(world: WorldData, region_id: str) -> Optional[Dict]:
    """Find a region by ID."""
    for region in world.regions:
        if region.id == region_id:
            return region
    return None


def find_city(world: WorldData, city_id: str):
    """Find a city by ID across all regions."""
    for region in world.regions:
        for city in region.cities:
            if city.id == city_id:
                return city
    return None


def get_world_summary(world: WorldData) -> Dict[str, Any]:
    """Get a summary of the world for display."""
    return {
        "num_regions": len(world.regions),
        "num_cities": sum(len(r.cities) for r in world.regions),
        "total_population": sum(
            sum(c.population for c in r.cities) for r in world.regions
        ),
        "regions": [
            {
                "name": r.name,
                "climate": r.climate,
                "terrain": r.terrain,
                "cities": [c.name for c in r.cities]
            }
            for r in world.regions
        ]
    }
