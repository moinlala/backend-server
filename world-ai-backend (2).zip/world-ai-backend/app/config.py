import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Application configuration."""
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
    ANTHROPIC_MODEL = os.getenv("ANTHROPIC_MODEL", "claude-3-5-sonnet-20241022")
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./world_data.db")
    DEBUG = os.getenv("DEBUG", "False") == "True"

config = Config()
