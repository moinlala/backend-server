from pydantic import BaseModel
from typing import List, Optional, Dict, Any
from datetime import datetime


class ResourceData(BaseModel):
    """Resource in a city."""
    name: str
    type: str  # mineral, agricultural, magical, etc
    quantity: int
    rarity: str  # common, rare, legendary


class CityData(BaseModel):
    """City within a region."""
    id: str
    name: str
    region_id: str
    population: int
    resources: List[ResourceData]
    description: str


class RegionData(BaseModel):
    """Region in the world."""
    id: str
    name: str
    climate: str
    terrain: str
    cities: List[CityData]
    description: str


class WorldData(BaseModel):
    """Complete world state."""
    regions: List[RegionData]
    metadata: Dict[str, Any]


class EventSuggestion(BaseModel):
    """Suggested event for the world."""
    type: str  # disaster, trade, conflict, discovery, etc
    description: str
    affected_regions: List[str]
    affected_cities: List[str]
    impact: str
    recommendations: List[str]


class UpdateRequest(BaseModel):
    """Request to update world state."""
    action: str  # "update_resource", "add_city", "add_event", etc
    target: str  # region_id or city_id
    changes: Dict[str, Any]
    reason: Optional[str] = None


class ValidationResult(BaseModel):
    """Result of validating an update."""
    is_valid: bool
    errors: List[str]
    warnings: List[str]
    recommendations: List[str]


class SnapshotResponse(BaseModel):
    """Snapshot metadata."""
    id: int
    description: str
    created_at: datetime

    class Config:
        orm_mode = True


class RollbackRequest(BaseModel):
    """Request to rollback to a snapshot."""
    snapshot_id: int
