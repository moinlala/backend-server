@echo off
REM Quick start script for Windows

echo ========================================
echo   World AI Backend - Quick Start
echo ========================================

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo Error: Python is not installed or not in PATH
    exit /b 1
)

echo.
echo Creating virtual environment...
python -m venv venv

echo.
echo Activating virtual environment...
call venv\Scripts\activate.bat

echo.
echo Installing dependencies...
pip install -r requirements.txt

echo.
echo.
echo ========================================
echo   Setup Complete!
echo ========================================
echo.
echo Next steps:
echo   1. Edit .env and add your ANTHROPIC_API_KEY
echo   2. Run the server: python app/main.py
echo   3. Visit http://localhost:8000/docs
echo.
echo To activate venv in the future:
echo   venv\Scripts\activate.bat
echo.
