"""
Unit tests for database service layer.
"""

import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database.models import Base, WorldState, Snapshot
from app.database.service import WorldStateService, EventService
from app.models.schemas import WorldData, RegionData, CityData, ResourceData

# Use in-memory SQLite for testing
SQLALCHEMY_TEST_DATABASE_URL = "sqlite:///:memory:"

engine = create_engine(
    SQLALCHEMY_TEST_DATABASE_URL, connect_args={"check_same_thread": False}
)
TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

@pytest.fixture
def db():
    """Create test database."""
    Base.metadata.create_all(bind=engine)
    db = TestingSessionLocal()
    yield db
    db.close()
    Base.metadata.drop_all(bind=engine)


def create_test_world():
    """Create a minimal test world."""
    resource = ResourceData(name="Iron", type="mineral", quantity=100, rarity="common")
    city = CityData(
        id="city_1",
        name="TestCity",
        region_id="region_1",
        population=10000,
        resources=[resource],
        description="Test city"
    )
    region = RegionData(
        id="region_1",
        name="TestRegion",
        climate="temperate",
        terrain="plains",
        cities=[city],
        description="Test region"
    )
    return WorldData(regions=[region], metadata={})


class TestWorldStateService:
    def test_get_or_create(self, db):
        """Test creating initial world state."""
        world = WorldStateService.get_or_create(db)
        assert world is not None
        assert world.id is not None
        
    def test_update_world(self, db):
        """Test updating world state."""
        world_data = create_test_world()
        updated = WorldStateService.update(db, world_data)
        assert updated is not None
        assert len(updated.data["regions"]) == 1
        
    def test_get_data(self, db):
        """Test retrieving world data."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        retrieved = WorldStateService.get_data(db)
        assert len(retrieved.regions) == 1
        assert retrieved.regions[0].name == "TestRegion"
    
    def test_create_snapshot(self, db):
        """Test snapshot creation."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        snapshot = WorldStateService.create_snapshot(db, "Test snapshot")
        assert snapshot is not None
        assert snapshot.description == "Test snapshot"
        assert len(snapshot.data["regions"]) == 1
    
    def test_list_snapshots(self, db):
        """Test listing snapshots."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        # Create multiple snapshots
        for i in range(3):
            WorldStateService.create_snapshot(db, f"Snapshot {i}")
        
        snapshots = WorldStateService.list_snapshots(db, limit=10)
        assert len(snapshots) == 3
    
    def test_rollback_to_snapshot(self, db):
        """Test rollback functionality."""
        # Create initial world
        world_data_1 = create_test_world()
        WorldStateService.update(db, world_data_1)
        snapshot_1 = WorldStateService.create_snapshot(db, "Snapshot 1")
        
        # Modify world
        world_data_2 = create_test_world()
        world_data_2.regions[0].cities[0].population = 50000
        WorldStateService.update(db, world_data_2)
        
        # Rollback
        WorldStateService.rollback_to_snapshot(db, snapshot_1.id)
        
        # Verify
        current = WorldStateService.get_data(db)
        assert current.regions[0].cities[0].population == 10000


class TestEventService:
    def test_add_event(self, db):
        """Test adding an event."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        event_data = {"type": "test_event", "description": "A test event"}
        event = EventService.add_event(db, event_data)
        
        assert event is not None
        assert event.status == "suggested"
        assert event.event_data["type"] == "test_event"
    
    def test_get_events(self, db):
        """Test retrieving events."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        # Add multiple events
        for i in range(3):
            EventService.add_event(db, {"type": f"event_{i}"})
        
        events = EventService.get_events(db)
        assert len(events) == 3
    
    def test_filter_events_by_status(self, db):
        """Test filtering events by status."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        # Add events with different statuses
        e1 = EventService.add_event(db, {"type": "event_1"}, status="suggested")
        e2 = EventService.add_event(db, {"type": "event_2"}, status="applied")
        
        suggested = EventService.get_events(db, status="suggested")
        applied = EventService.get_events(db, status="applied")
        
        assert len(suggested) == 1
        assert len(applied) == 1
    
    def test_update_event_status(self, db):
        """Test updating event status."""
        world_data = create_test_world()
        WorldStateService.update(db, world_data)
        
        event = EventService.add_event(db, {"type": "test"}, status="suggested")
        updated = EventService.update_event_status(db, event.id, "applied")
        
        assert updated.status == "applied"
