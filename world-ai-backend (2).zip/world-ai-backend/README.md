# World AI Backend

A lightweight, AI-powered backend system for generating, managing, and validating fantasy world data.

## Overview

This system uses Claude AI to:
- **Generate** realistic worlds with regions, cities, and resources
- **Validate** update requests before applying them
- **Suggest** logical events based on world state
- **Track** changes with snapshots and enable rollback

Perfect for game development, worldbuilding, or creative projects needing structured data with AI-powered logic.

## Features

- 🌍 **AI World Generation**: Generate complete worlds with coherent regions, cities, and resources
- ✅ **Smart Validation**: AI-powered validation of proposed updates for logical consistency
- 📊 **Event Suggestions**: AI suggests realistic events based on world state
- 💾 **Snapshots & Rollback**: Full history with point-in-time rollback capability
- 🚀 **Clean API**: RESTful endpoints with interactive Swagger docs
- 📦 **SQLite Database**: Lightweight, file-based storage (easily upgradeable to Postgres)

## Architecture

```
world-ai-backend/
├── app/
│   ├── agents/               # AI agents for generation and validation
│   │   ├── world_generator.py   # World generation via Claude
│   │   └── validator.py         # Update validation and application
│   ├── database/             # Database layer
│   │   ├── models.py           # SQLAlchemy models and database setup
│   │   └── service.py          # Database service methods
│   ├── models/               # Pydantic schemas
│   │   └── schemas.py          # Request/response models
│   ├── routes/               # API endpoints
│   │   ├── world.py            # World management endpoints
│   │   └── health.py           # Health check and root endpoint
│   ├── utils/                # Utility functions
│   │   └── helpers.py          # Common helper functions
│   ├── config.py             # Configuration management
│   └── main.py               # FastAPI app initialization
├── tests/                    # Test suite
├── requirements.txt          # Python dependencies
├── .env.example              # Environment variables template
└── README.md                 # This file
```

## Quick Start - One Command

```bash
# Windows (PowerShell)
$env:ANTHROPIC_API_KEY = 'your-api-key-here'
python run.py

# Linux/macOS
export ANTHROPIC_API_KEY='your-api-key-here'
python run.py
```

This command will:
1. ✅ Start the FastAPI server on `http://localhost:8000`
2. ✅ Generate a sample world with 3 regions
3. ✅ Suggest events and demonstrate validation
4. ✅ Save snapshots to `/storage/snapshots/`
5. ✅ Show all API responses with clean JSON formatting

**The server will keep running** after the example completes. Open **http://localhost:8000/docs** for interactive API documentation.

## Deliverables ✅

### 1. **Working Repository**
- ✅ Full FastAPI backend with clean structure
- ✅ AI agents for generation, validation, and suggestions
- ✅ SQLite database with snapshots and rollback
- ✅ Complete test suite with example workflows

### 2. **Setup Instructions**
- ✅ One-command startup: `python run.py`
- ✅ Manual setup steps for customization
- ✅ Environment configuration (.env support)
- ✅ Dependency management (requirements.txt)

### 3. **Sample World Generation**
- ✅ Deterministic JSON output with clean formatting
- ✅ 3-region sample world with cities and resources
- ✅ AI-generated metadata and descriptions
- ✅ Reproducible on each run

### 4. **Example Output Files**
- ✅ Snapshot system: `/storage/snapshots/`
- ✅ Sample snapshots saved as clean JSON
- ✅ Event suggestions with impact analysis
- ✅ Validation results and recommendations

### 5. **Complete API Documentation**
- ✅ Interactive Swagger UI at `/docs`
- ✅ All endpoints documented with examples
- ✅ Request/response schemas defined
- ✅ Error handling and status codes

### 6. **Example Usage Script**
- ✅ `example_usage.py` demonstrates all endpoints
- ✅ Complete workflow from generation to rollback
- ✅ Pretty-printed JSON responses
- ✅ Error handling and retry logic

## Manual Setup

If you prefer to set up step-by-step:

### Prerequisites
- Python 3.9+
- Anthropic API key (get one at [console.anthropic.com](https://console.anthropic.com))

### Installation

1. **Clone and navigate to the project:**
   ```powershell
   cd "d:\mvp client\world-ai-backend"
   ```

2. **Create a virtual environment:**
   ```powershell
   python -m venv venv
   venv\Scripts\Activate.ps1
   ```

3. **Install dependencies:**
   ```powershell
   pip install -r requirements.txt
   ```

4. **Set up environment variables:**
   ```powershell
   Copy-Item .env.example .env
   # Edit .env and add your ANTHROPIC_API_KEY
   ```

5. **Run the server:**
   ```powershell
   python -m uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
   ```

   Or simply:
   ```powershell
   python app/main.py
   ```

6. **Access the API:**
   - 🚀 API: `http://localhost:8000`
   - 📚 Swagger Docs: `http://localhost:8000/docs`
   - 🎯 ReDoc: `http://localhost:8000/redoc`

## API Endpoints

### World Management

#### Generate New World
```http
POST /api/world/generate?num_regions=3
```
Generates a new world with specified number of regions. Creates initial snapshot.

**Response:** WorldData object with regions, cities, resources

---

#### Get Current World
```http
GET /api/world/current
```
Retrieves the current world state.

**Response:** Full WorldData structure

---

#### Get World Summary
```http
GET /api/world/summary
```
Quick overview of world (counts, names, structure).

**Response:**
```json
{
  "num_regions": 3,
  "num_cities": 8,
  "total_population": 250000,
  "regions": [...]
}
```

### Updates & Validation

#### Validate Update
```http
POST /api/world/validate
Content-Type: application/json

{
  "action": "update_resource",
  "target": "city_1",
  "changes": {
    "population": 75000
  },
  "reason": "Population growth from trade"
}
```

Validates update without applying it.

**Response:** ValidationResult with is_valid, errors, warnings, recommendations

---

#### Apply Update
```http
POST /api/world/update
Content-Type: application/json

{
  "action": "update_resource",
  "target": "city_1",
  "changes": {
    "population": 75000
  },
  "reason": "Population growth"
}
```

Validates and applies the update if valid.

**Response:**
```json
{
  "success": true,
  "message": "Updated city city_1: Population growth",
  "snapshot_id": 3,
  "warnings": [],
  "recommendations": []
}
```

### Events

#### Suggest Event
```http
POST /api/world/events/suggest
```
AI suggests a new event based on current world state.

**Response:**
```json
{
  "event_id": 1,
  "event": {
    "type": "trade_boom",
    "description": "A major trade route opens between coastal cities",
    "affected_regions": ["region_1", "region_2"],
    "affected_cities": ["city_1", "city_2"],
    "impact": "Economic prosperity in affected cities",
    "recommendations": ["Increase resources", "Hire more merchants"]
  }
}
```

---

#### List Events
```http
GET /api/world/events?status=suggested
```
List events optionally filtered by status (suggested, applied, rejected).

---

#### Apply Event
```http
POST /api/world/events/{event_id}/apply
```
Mark event as applied and create a snapshot.

### Snapshots & Rollback

#### Create Snapshot
```http
POST /api/world/snapshots?description=After%20major%20event
```
Manually create a snapshot of current state.

---

#### List Snapshots
```http
GET /api/world/snapshots?limit=10
```
List available snapshots for rollback.

---

#### Rollback
```http
POST /api/world/rollback
Content-Type: application/json

{
  "snapshot_id": 2
}
```
Restore world to a previous snapshot. Creates backup of current state.

## Database Schema

### Tables

**world_state**
- Current world data as JSON
- Updated automatically with changes

**snapshots**
- Point-in-time backups of world_state
- Linked to world_state for history tracking

**events**
- All suggested, applied, or rejected events
- Audit trail of world modifications

## Example Workflow

```powershell
# 1. Generate a new world
curl -X POST http://localhost:8000/api/world/generate?num_regions=3

# 2. View the summary
curl http://localhost:8000/api/world/summary

# 3. Suggest an event
curl -X POST http://localhost:8000/api/world/events/suggest

# 4. View suggested events
curl http://localhost:8000/api/world/events?status=suggested

# 5. Validate an update
curl -X POST http://localhost:8000/api/world/validate `
  -H "Content-Type: application/json" `
  -d '{
    "action": "update_resource",
    "target": "city_1",
    "changes": {"population": 100000},
    "reason": "Growth"
  }'

# 6. Apply the update
curl -X POST http://localhost:8000/api/world/update `
  -H "Content-Type: application/json" `
  -d '{
    "action": "update_resource",
    "target": "city_1",
    "changes": {"population": 100000},
    "reason": "Growth"
  }'

# 7. View snapshots
curl http://localhost:8000/api/world/snapshots

# 8. Rollback if needed
curl -X POST http://localhost:8000/api/world/rollback `
  -H "Content-Type: application/json" `
  -d '{"snapshot_id": 1}'
```

## Configuration

Edit `.env` to customize:

```env
# Anthropic API configuration
ANTHROPIC_API_KEY=sk-ant-...

# Database (defaults to SQLite)
DATABASE_URL=sqlite:///./world_data.db

# Debug mode
DEBUG=True
```

### Using PostgreSQL (Optional)

To upgrade to PostgreSQL:

1. Install psycopg2: `pip install psycopg2-binary`
2. Update DATABASE_URL in `.env`:
   ```env
   DATABASE_URL=postgresql://user:password@localhost/world_db
   ```

## Development

### Running Tests
```powershell
pytest tests/ -v
```

### Project Structure Philosophy

- **Agents**: Pure AI logic (generation, validation, suggestions)
- **Database**: Data persistence and querying
- **Routes**: HTTP endpoints and request handling
- **Models**: Shared schemas for validation
- **Utils**: Common helper functions

Each module is independent and testable.

## Performance Notes

- **World generation**: ~5-10 seconds (Claude API)
- **Update validation**: ~3-5 seconds (Claude API)
- **Event suggestion**: ~5-8 seconds (Claude API)
- **Database operations**: <100ms

All AI operations are network-bound. Consider adding async support for concurrent requests.

## Error Handling

API returns appropriate HTTP status codes:
- `200`: Success
- `400`: Validation failed (invalid update)
- `404`: Resource not found
- `500`: Server error (usually Claude API timeout)

## Future Enhancements

- ⚡ Async endpoint support for concurrent AI calls
- 🔒 Authentication and authorization
- 📈 Metrics and logging
- 🎨 More sophisticated world generation templates
- 🧪 Expanded test suite
- 🔄 Event chains and dependencies
- 🌐 WebSocket support for real-time updates

## License

MIT

## Support

For issues with the Anthropic API, visit: https://docs.anthropic.com

For FastAPI documentation: https://fastapi.tiangolo.com
