#!/usr/bin/env python
"""
Run script to start the World AI Backend server and execute example usage.
Usage: python run.py
"""

import subprocess
import time
import sys
import os
import threading
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

def main():
    print("\n" + "="*70)
    print("  " + " "*15 + "🌍 World AI Backend - Test Phase")
    print("="*70)
    
    project_root = Path(__file__).parent
    
    # 1. Check environment
    print("\n[1/4] Checking environment...")
    if not os.getenv("ANTHROPIC_API_KEY"):
        print("  ⚠️  Warning: ANTHROPIC_API_KEY not set in environment")
        print("     Set it with: $env:ANTHROPIC_API_KEY='your-key' (PowerShell)")
        print("     Or in a .env file in the project root")
        print("     Setup will continue - .env file will be checked by app")
    else:
        print("  ✓ ANTHROPIC_API_KEY found in environment")
    
    # 2. Install dependencies if needed
    print("\n[2/4] Checking dependencies...")
    try:
        subprocess.run(
            "pip install -q -r requirements.txt",
            shell=True,
            cwd=str(project_root),
            check=True,
            capture_output=True
        )
        print("  ✓ Dependencies installed")
    except Exception as e:
        print(f"  ✗ Error installing dependencies: {e}")
        return
    
    # 3. Create snapshots directory
    print("\n[3/4] Preparing storage...")
    snapshots_dir = project_root / "storage" / "snapshots"
    snapshots_dir.mkdir(parents=True, exist_ok=True)
    print(f"  ✓ Snapshots directory ready: {snapshots_dir}")
    
    # 4. Start server in background
    print("\n[4/4] Starting server...")
    print("  Launching FastAPI server on http://localhost:8000")
    
    # Start server as background process
    server_process = subprocess.Popen(
        "python -m uvicorn app.main:app --host 0.0.0.0 --port 8000",
        shell=True,
        cwd=str(project_root)
    )
    
    # Wait for server to start
    print("  Waiting for server to initialize...")
    server_ready = False
    for attempt in range(60):
        try:
            import requests
            response = requests.get("http://localhost:8000/health", timeout=2)
            if response.status_code == 200:
                print("  ✓ Server is ready!")
                server_ready = True
                break
        except:
            pass
        
        if attempt > 0 and attempt % 10 == 0:
            print(f"    (waiting... {attempt}s)")
        time.sleep(1)
    
    if not server_ready:
        print("  ⚠️  Server startup timeout - but continuing anyway...")
        time.sleep(3)
    
    print("\n" + "="*70)
    print("  Running example API usage demonstrating all endpoints...")
    print("="*70 + "\n")
    
    # Run example usage
    try:
        subprocess.run(
            "python example_usage.py",
            shell=True,
            cwd=str(project_root),
            timeout=120
        )
    except subprocess.TimeoutExpired:
        print("\n  ⚠️  Example timed out (this can happen with API rate limits)")
    except Exception as e:
        print(f"\n  ✗ Error running examples: {e}")
    
    # Summary
    print("\n" + "="*70)
    print("  ✅ Test Phase Complete!")
    print("="*70)
    print("\n📋 Next Steps:")
    print(f"  1. Server is running at: http://localhost:8000")
    print(f"  2. Interactive Docs: http://localhost:8000/docs")
    print(f"  3. Snapshots saved to: storage/snapshots/")
    print(f"  4. Database: world_data.db")
    print("\n💡 Examples:")
    print("     python example_usage.py  # Run examples again")
    print("     curl http://localhost:8000/health  # Health check")
    print("     curl http://localhost:8000/api/world/summary  # Get world summary")
    print("\n🛑 To stop the server: Press Ctrl+C")
    print("="*70)
    
    # Keep server running
    try:
        server_process.wait()
    except KeyboardInterrupt:
        print("\n\n  ✓ Shutting down server...")
        server_process.terminate()
        try:
            server_process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            server_process.kill()
        print("  ✓ Server stopped")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n\n  ✓ Stopped")
    except Exception as e:
        print(f"\n✗ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
