"""
Example usage of the World AI Backend API.
Run this script to test the system.
"""

import requests
import json
from time import sleep

BASE_URL = "http://localhost:8000"

def print_section(title):
    print(f"\n{'='*60}")
    print(f"  {title}")
    print(f"{'='*60}\n")

def main():
    print_section("World AI Backend - Example Usage")
    
    # 1. Health check
    print("1. Checking server health...")
    response = requests.get(f"{BASE_URL}/health")
    print(f"   Status: {response.json()['status']}")
    
    # 2. Generate world
    print_section("2. Generating New World (3 regions)")
    print("   Please wait, this calls Claude AI (~10 seconds)...")
    response = requests.post(f"{BASE_URL}/api/world/generate?num_regions=3")
    if response.status_code == 200:
        world = response.json()
        print(f"   ✓ Generated world with {len(world['regions'])} regions")
        for region in world['regions']:
            print(f"     - {region['name']}: {len(region['cities'])} cities")
    else:
        print(f"   ✗ Error: {response.text}")
        return
    
    # 3. Get summary
    print_section("3. World Summary")
    response = requests.get(f"{BASE_URL}/api/world/summary")
    summary = response.json()
    print(f"   Total Regions: {summary['num_regions']}")
    print(f"   Total Cities: {summary['num_cities']}")
    print(f"   Total Population: {summary['total_population']:,}")
    
    # 4. Validate an update
    print_section("4. Validating a World Update")
    update_request = {
        "action": "update_resource",
        "target": world['regions'][0]['cities'][0]['id'],
        "changes": {
            "population": 150000
        },
        "reason": "Discovered major trade opportunity"
    }
    print(f"   Update: Increase population of {world['regions'][0]['cities'][0]['name']}")
    response = requests.post(f"{BASE_URL}/api/world/validate", json=update_request)
    validation = response.json()
    print(f"   Valid: {validation['is_valid']}")
    if validation['errors']:
        print(f"   Errors: {validation['errors']}")
    if validation['warnings']:
        print(f"   Warnings: {validation['warnings']}")
    if validation['recommendations']:
        print(f"   Recommendations:")
        for rec in validation['recommendations']:
            print(f"     - {rec}")
    
    # 5. Apply the update
    if validation['is_valid']:
        print_section("5. Applying Update")
        response = requests.post(f"{BASE_URL}/api/world/update", json=update_request)
        result = response.json()
        if result.get('success'):
            print(f"   ✓ {result['message']}")
            print(f"   Snapshot ID: {result['snapshot_id']}")
        else:
            print(f"   ✗ {result}")
    
    # 6. Suggest event
    print_section("6. Suggesting a World Event")
    print("   Analyzing world state and suggesting event...")
    response = requests.post(f"{BASE_URL}/api/world/events/suggest")
    if response.status_code == 200:
        event_response = response.json()
        event = event_response['event']
        print(f"   Event Type: {event['type']}")
        print(f"   Description: {event['description']}")
        print(f"   Affected Regions: {', '.join(event['affected_regions'])}")
        print(f"   Impact: {event['impact']}")
        print(f"   Recommendations:")
        for rec in event['recommendations']:
            print(f"     - {rec}")
    else:
        print(f"   ✗ Error: {response.text}")
    
    # 7. List events
    print_section("7. Listing Events")
    response = requests.get(f"{BASE_URL}/api/world/events")
    events = response.json()
    print(f"   Total Events: {len(events)}")
    for evt in events[:3]:
        print(f"   - {evt['data'].get('type', 'unknown')}: {evt['status']}")
    
    # 8. List snapshots
    print_section("8. Available Snapshots")
    response = requests.get(f"{BASE_URL}/api/world/snapshots")
    snapshots = response.json()
    print(f"   Total Snapshots: {len(snapshots)}")
    for snap in snapshots:
        print(f"   - Snapshot #{snap['id']}: {snap['description']}")
    
    # 9. Rollback example (optional)
    if len(snapshots) > 1:
        print_section("9. Rollback Example")
        print(f"   Note: This would rollback to snapshot #{snapshots[-1]['id']}")
        print(f"   Uncomment the code below to test rollback:")
        print()
        print(f"   # response = requests.post(f'{{BASE_URL}}/api/world/rollback',")
        print(f"   #     json={{'snapshot_id': {snapshots[-1]['id']}}}")
        print(f"   # print(response.json())")
    
    print_section("✓ Example Complete")
    print("   Visit http://localhost:8000/docs for interactive API documentation")

if __name__ == "__main__":
    try:
        main()
    except requests.exceptions.ConnectionError:
        print("\n✗ Error: Could not connect to server")
        print("   Make sure the server is running: python -m uvicorn app.main:app --reload")
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
